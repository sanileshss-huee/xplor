import { getStore } from "@netlify/blobs";

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" }
  });

export default async (req) => {
  const expected = Netlify.env.get("DASHBOARD_PASSWORD");
  if (!expected) return json({ error: "DASHBOARD_PASSWORD is not set on the server" }, 500);
  if (req.headers.get("x-password") !== expected) return json({ error: "Wrong password" }, 401);

  const store = getStore({ name: "inventory", consistency: "strong" });

  if (req.method === "GET") {
    const data = await store.get("stock", { type: "json" });
    return json(data || {});
  }

  if (req.method === "POST") {
    let body;
    try { body = await req.json(); } catch { return json({ error: "Bad request" }, 400); }
    const updates = body && body.updates;
    if (!updates || typeof updates !== "object") return json({ error: "Bad request" }, 400);

    const current = (await store.get("stock", { type: "json" })) || {};
    for (const [key, value] of Object.entries(updates)) {
      if (/^[a-z0-9-]+$/.test(key) && Number.isFinite(value) && value >= 0) {
        current[key] = Math.floor(value);
      }
    }
    await store.setJSON("stock", current);
    return json(current);
  }

  return json({ error: "Method not allowed" }, 405);
};

export const config = { path: "/api/stock" };
